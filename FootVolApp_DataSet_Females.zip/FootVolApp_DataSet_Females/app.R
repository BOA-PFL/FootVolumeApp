#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinythemes)
library(data.table)
library(DT)

rm(list=ls()) 
not_sel <- "Not Selected"


main_page <- tabPanel(
  title = "Analysis",
  titlePanel("Analysis"),
  sidebarLayout(
    sidebarPanel(
      title = "Inputs",
      
      ##----Shoe Size Slider ---
      sliderInput("ShoeSize", label = h3("Select Shoe Size"),min = 6, 
                  max = 15, value = c(9), step = 0.5),
      
      br(),
      h4('Once you have selected a size', span("Run Analysis.", style = "color:blue"), 
         "If you would like to look at new metrics in a different shoe size, click",  span("Run Analysis", style = "color:blue"), "again to refresh the page."),
      actionButton("run_button", "Run Analysis", icon = icon("play")),
      br(),  
      strong(h4('How the measurments were taken', style = "color:orange")),
      fluidRow(
        column( 10,img(src = "Aetrex_foot length.png", height = 265, width = 130),
                img(src = "Aetres width.png", height = 265, width = 130))
      ),
      fluidRow(
        column( 10, img(src = "aetres instep.png", align = "Center", title = "Instep", height = 170, width = 225), 
                img(src = "Girth.PNG", align = "Center", height = 170, width = 225))
      )
      
    ),
    mainPanel(
      tabsetPanel(
        tabPanel(
          title = "Data Tables",  
          DT::dataTableOutput("mytable"),
          
          fluidRow(
            column(width = 4, strong(textOutput("num_var_1_title"))),
            column(width = 4, strong(textOutput("num_var_2_title"))),
            column(width = 4, strong(textOutput("num_var_3_title"))),
            
          ),
          fluidRow(
            column(width = 4, tableOutput("num_var_1_summary_table")),
            column(width = 4, tableOutput("num_var_2_summary_table")),
            column(width = 4, tableOutput("num_var_3_summary_table")),
            
          ),
          fluidRow(
            column(width = 4, strong(textOutput("num_var_4_title"))),
            column(width = 4, strong(textOutput("num_var_5_title"))),
            column(width = 4, strong(textOutput("fact_var_title"))),
            
          ),
          fluidRow(
            column(width = 4, tableOutput("num_var_4_summary_table")),
            column(width = 4, tableOutput("num_var_5_summary_table")) 
          ),
          fluidRow(
            h4(span(style = "color:blue", "* Note:"), style = "color:black"),
            h5(span( "- These metrics are based off the assigned shoe size via Aetrex (the foot scanning software). The shoe size that a tester would typically regularly wear is in the column 'RepShoeSize'." )),  
            h5(span("- If you are looking for a high or low volume foot, it is important to note that:")),
            h5(span("1.) high volume may be defined differently depending on who is defining it (length vs width, or intep vs length, etc.)")),
            h5(span("2.)Not all metrics are correlated with each other. Ex. a wide forefoot may not correlate with a high instep")), 
            h5(span(style = "color:green","If you have any questions about the app, please contact Bethany.Kilpatrick@boatechnology.com"))
          ),
          
        )
      )
    )
  )
)



ui <- navbarPage(
  title = "BOA Foot Volume App via BigData",
  theme = shinytheme('sandstone'),
  main_page
  
  
)

server <- function(input, output){
  
  
  create_num_var_table <- function(data_input, num_var){
    if(num_var != not_sel){
      col <- data_input[,num_var]
      if (length(col)>5000) col_norm <- sample(col,5000) else col_norm <- col
      statistic <- c("5th percentile - Low end","25th percentile - Mid Low", "50th percentile - Average",
                     "75th percentile - Mid High", "95th percentile - High end"
      )
      value <- c(round(quantile(col, 0.05, na.rm = TRUE),2),round(quantile(col, 0.25, na.rm = TRUE),2),round(quantile(col,0.5, na.rm = TRUE),2),
                 round(quantile(col, 0.75, na.rm = TRUE),2), round(quantile(col, 0.95,na.rm = TRUE),2)
      )
      data.table(statistic, value)
    }
  }
  
  
  data_input <- reactive({
    read.csv("data/MasterSubjectSizes_Male.csv") 
    
    
  })
  
  
  #Sliders 
  #-----------------
  df_subset <- reactive({
    a <- subset(data_input(), ShoeSize == input$ShoeSize)
    return(a)
  }) 
  
  
  
  # Data Table  
  #-----------------
  
  output$mytable = DT::renderDataTable({
    
    df_subset()
    
  })
  
  
  
  
  # 1-d summary tables 
  #-----------------
  
  output$num_var_1_title <- renderText("Length (cm)")
  
  num_var_1_summary_table <- eventReactive(input$run_button,{
    create_num_var_table(df_subset(),   7)
    
  })
  
  output$num_var_1_summary_table <- renderTable(num_var_1_summary_table(),colnames = FALSE)
  
  
  
  output$num_var_2_title <- renderText("Width (cm)")
  
  num_var_2_summary_table <- eventReactive(input$run_button,{
    create_num_var_table(df_subset(), 8)
    
  })
  
  output$num_var_2_summary_table <- renderTable(num_var_2_summary_table(),colnames = FALSE)
  
  
  
  output$num_var_3_title <- renderText("Instep (cm)")
  
  num_var_3_summary_table <- eventReactive(input$run_button,{
    create_num_var_table(df_subset(), 9)
    
  })
  
  output$num_var_3_summary_table <- renderTable(num_var_3_summary_table(),colnames = FALSE)
  
  
  
  
  output$num_var_4_title <- renderText("Girth (cm)")
  
  num_var_4_summary_table <- eventReactive(input$run_button,{
    create_num_var_table(df_subset(), 10)
    
  })
  
  output$num_var_4_summary_table <- renderTable(num_var_4_summary_table(),colnames = FALSE)
  
  
  output$fact_var_title <- renderText(paste (length(unique(df_subset()[,3])), "| Number of unique subjects in this shoe size"))
  
}


shinyApp(ui = ui, server = server)
