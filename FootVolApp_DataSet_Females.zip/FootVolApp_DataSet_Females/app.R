#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(shinythemes)
library(data.table)
library(DT) 





rm(list=ls()) 
 


not_sel <- "Not Selected"


main_page <- tabPanel(
    title = "Analysis",
    titlePanel("Analysis"),
    sidebarLayout(
        sidebarPanel(
            title = "Inputs",
            
            #-----Loading a csv in--------#
            # fileInput("csv_input", "Select a CSV File to Import", accept = ".csv"),
            
            selectInput("num_var_1", "Length", choices = c("Length")),
            selectInput("num_var_2", "Width", choices = c("Width")),
            selectInput("num_var_3", "Instep", choices = c("Instep")),
            selectInput("num_var_4", "Girth", choices = c("Girth")),
            
            #----Factor Variable - ie. how many of each shoe size
           
            
            selectInput("fact_var", "How many people per shoe size", choices = c("ShoeSize")),
            
            ##----Shoe Size Slider ---
            sliderInput("ShoeSize", label = h3("Select Shoe Size"),min = 5, 
                        max = 15, value = c(9), step = 0.5),
            
            br(),
            h4('Once you have uploaded a Table and selected a variable, press', span("Run Analysis.", style = "color:blue"), 
               "If you would like to look at new metrics in a different shoe size, click",  span("Run Analysis", style = "color:blue"), "again to refresh the page."),
            actionButton("run_button", "Run Analysis", icon = icon("play")),
            br(),  
            strong(h4('How the measurments were taken', style = "color:orange")),
            fluidRow(
                column( 10,img(src = "Aetrex_foot length.png", height = 265, width = 130),
                        img(src = "Aetres width.png", height = 265, width = 130))
            ),
            fluidRow(
                column( 10, img(src = "aetres instep.png", align = "Center", title = "Instep", height = 170, width = 225), 
                        img(src = "Girth.PNG", align = "Center", height = 170, width = 225))
            )
            
        ),
        mainPanel(
            tabsetPanel(
                tabPanel(
                    title = "Data Tables",  
                    DT::dataTableOutput("mytable"),
                    # read.csv("data/MasterSubjectSizes_Male.csv")
                    
                    fluidRow(
                        column(width = 4, strong(textOutput("num_var_1_title"))),
                        column(width = 4, strong(textOutput("num_var_2_title"))),
                        column(width = 4, strong(textOutput("num_var_3_title"))),
                        
                    ),
                    fluidRow(
                        column(width = 4, tableOutput("num_var_1_summary_table")),
                        column(width = 4, tableOutput("num_var_2_summary_table")),
                        column(width = 4, tableOutput("num_var_3_summary_table")),
                        
                    ),
                    fluidRow(
                        column(width = 4, strong(textOutput("num_var_4_title"))),
                        column(width = 4, strong(textOutput("num_var_5_title"))),
                        column(width = 4, strong(textOutput("fact_var_title"))),
                        
                    ),
                    fluidRow(
                        column(width = 4, tableOutput("num_var_4_summary_table")),
                        column(width = 4, tableOutput("num_var_5_summary_table")), 
                        column(width = 4, tableOutput("fact_var_summary_table")),  
                    ),
                    fluidRow(
                        h4(span(style = "color:blue", "* Note:"), style = "color:black"),
                        h5(span( "- These metrics are based off of the assigned shoe size via Aetrex (the foot scanning software). The shoe size that a tester would typically regularly wear is in the column 'RepShoeSize'." )),  
                        h5(span("- If you are looking for a high or low volume foot, it is important to note that:")),
                        h5(span("1.) high volume may be defined differently depending on who is defining it (length vs width, or intep vs length, etc.)")),
                        h5(span("2.)Not all metrics are correlated with each other. Ex. a wide forefoot may not correlate with a high instep")), 
                        h5(span(style = "color:green","If you have any questions about the app, please contact Bethany.Kilpatrick@boatechnology.com"))
                        ),
                    
                )
            )
        )
    )
)



create_num_var_table <- function(data_input, num_var){
    if(num_var != not_sel){
        col <- data_input[,num_var]
        if (length(col)>5000) col_norm <- sample(col,5000) else col_norm <- col
        norm_test <- shapiro.test(col_norm)
        statistic <- c("5th percentile - Low end","25th percentile - Mid Low", "50th percentile - Average",
                       "75th percentile - Mid High", "95th percentile - High end"
        )
        value <- c(round(quantile(col, 0.05, na.rm = TRUE),2),round(quantile(col, 0.25, na.rm = TRUE),2),round(quantile(col,0.5, na.rm = TRUE),2),
                   round(quantile(col, 0.75, na.rm = TRUE),2), round(quantile(col, 0.95,na.rm = TRUE),2)
        )
        data.table(statistic, value)
    }
}

create_fact_var_table <- function(data_input, fact_var){
  if(fact_var != not_sel){
    freq_tbl <- data_input[,.N/2, by = get(fact_var) ]
    freq_tbl <- setnames(freq_tbl,c("factor_value", "count"))
    freq_tbl
  }
}

#by = get(fact_var) 

ui <- navbarPage(
    title = "BOA Foot Volume App via BigData",
    theme = shinytheme('sandstone'),
    main_page
    
    
)

server <- function(input, output, session){
    
    options(shiny.maxRequestSize=10*1024^2)
    # 
  
  #----Old reactive code------
    # data_input <- reactive({
    #     req(input$csv_input)
    #     fread(input$csv_input$datapath) 
  
  data_input <- reactive({
    read.csv("data/MasterSubjectSizes_Female.csv") 
    
  
    })

    

    
    observeEvent(data_input(),{
        choices <- c(not_sel,names(data_input()))
        updateSelectInput(inputId = "num_var_1", choices = 'Length')
        updateSelectInput(inputId = "num_var_2", choices = 'Width') 
        updateSelectInput(inputId = "num_var_3", choices = 'Instep')
        updateSelectInput(inputId = "num_var_4", choices = 'Girth')
        updateSelectInput(inputId = "num_var_5", choices = choices) 
        updateSelectInput(inputId = "fact_var", choices = 'ShoeSize')
    })
    num_var_1 <- eventReactive(input$run_button,input$num_var_1)
    num_var_2 <- eventReactive(input$run_button,input$num_var_2)
    num_var_3 <- eventReactive(input$run_button,input$num_var_3)
    num_var_4 <- eventReactive(input$run_button,input$num_var_4)
    num_var_5 <- eventReactive(input$run_button,input$num_var_5)
    fact_var <- eventReactive(input$run_button,input$fact_var)
    
  
    
    #Sliders 
    #-----------------
    df_subset <- reactive({
      a <- subset(data_input(), ShoeSize == input$ShoeSize)
      return(a)
    }) 

    
    
    # Data Table  
    #-----------------
    
    output$mytable = DT::renderDataTable({
      # read.csv("data/MasterSubjectSizes_Male.csv")
        df_subset()

    })

  
  
  
    # 1-d summary tables 
    #-----------------
    
    output$num_var_1_title <- renderText(paste(num_var_1(), "(cm)"))
    
    num_var_1_summary_table <- eventReactive(input$run_button,{
        create_num_var_table(df_subset(),   7)
        
    })
    
    output$num_var_1_summary_table <- renderTable(num_var_1_summary_table(),colnames = FALSE)
    
    
    
    output$num_var_2_title <- renderText(paste(num_var_2(), "(cm)"))
    
    num_var_2_summary_table <- eventReactive(input$run_button,{
        create_num_var_table(df_subset(), 8)
        
    })
    
    output$num_var_2_summary_table <- renderTable(num_var_2_summary_table(),colnames = FALSE)
    
    
    
    output$num_var_3_title <- renderText(paste(num_var_3(), "(cm)"))
    
    num_var_3_summary_table <- eventReactive(input$run_button,{
        create_num_var_table(df_subset(), 9)
        
    })
    
    output$num_var_3_summary_table <- renderTable(num_var_3_summary_table(),colnames = FALSE)
    
    
    
    
    output$num_var_4_title <- renderText(paste(num_var_4(), "(cm)"))
    
    num_var_4_summary_table <- eventReactive(input$run_button,{
        create_num_var_table(df_subset(), 10)
        
    })
    
    output$num_var_4_summary_table <- renderTable(num_var_4_summary_table(),colnames = FALSE)
    
    
    

    
    
    output$fact_var_title <- renderText(paste (dim(df_subset()[1]), "| Number of people per shoe size"))
    
}


shinyApp(ui = ui, server = server)
